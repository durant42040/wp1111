import React from 'react'

const App = () => {
  return (
    <div id="pretest">This is the pretest. DO NOT MODIFY ANYTHING.</div>
  )
}

export default App
